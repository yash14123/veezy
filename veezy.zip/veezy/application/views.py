from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
# Create your views here.
from .forms import SignupForm,CheckRequirementForm,Step1Form,Step2Form,Step3Form,Step4Form,Step5Form
from .models import Application
import hashlib
import uuid
import boto
from boto.s3.connection import S3Connection
from django.core.files.storage import FileSystemStorage
import os
import sys
s3 = S3Connection('AKIAJ3P4ANN6OM7N2S4Q', 'RTcLqErpKcLz0sQ5teN+qXnPWvl07VQ7Wv8R48VL')
bucket = s3.get_bucket('veezydocuments')

def index(request):
	return render(request, 'application/index.html')

def view_404(request):
	return redirect('index')

@login_required
def dashboard(request):
	user_applications = Application.objects.all().filter(username=request.user.username)
	return render(request, 'application/dashboard.html',{'user_applications':user_applications})

@login_required
def step1(request,application_id):
	if request.method=='POST':
		form = Step1Form(request.POST)
		if form.is_valid():
			application = Application.objects.get(pk=application_id)
			

			surname = form.cleaned_data.get('surname')
			surname_at_birth = form.cleaned_data.get('surname_at_birth')
			name = form.cleaned_data.get('name')
			date_of_birth = form.cleaned_data.get('date_of_birth')
			place_of_birth = form.cleaned_data.get('place_of_birth')
			country_of_birth = form.cleaned_data.get('country_of_birth')
			passport_nationality = form.cleaned_data.get('passport_nationality')
			nationality_at_birth = form.cleaned_data.get('nationality_at_birth')
			gender = form.cleaned_data.get('gender')
			martial_status = form.cleaned_data.get('martial_status')

			application.surname = surname
			application.surname_at_birth = surname_at_birth
			application.name = name
			application.date_of_birth = date_of_birth
			application.place_of_birth = place_of_birth
			application.country_of_birth = country_of_birth
			application.passport_nationality = passport_nationality
			application.nationality_at_birth = nationality_at_birth
			application.gender = gender
			application.martial_status = martial_status


			application.save()
			return redirect('step2',application_id=application_id)
		else:
			return render(request, 'application/step1.html',{'application_id':application_id,'form':form})

	else:
		form = Step1Form()
		application = Application.objects.get(pk=application_id)
		if application.surname is not None:
			form = Step1Form(initial={
			'surname':application.surname,
			'surname_at_birth':application.surname_at_birth,
			'name':application.name,
			'date_of_birth':application.date_of_birth,
			'place_of_birth':application.place_of_birth,
			'country_of_birth':application.country_of_birth,
			'passport_nationality':application.passport_nationality,
			'nationality_at_birth':application.nationality_at_birth,
			'gender':application.gender,
			'martial_status':application.martial_status,
			})

		return render(request, 'application/step1.html',{'application_id':application_id,'form':form,'application':application})

@login_required
def step2(request,application_id):
	if request.method=='POST':
		form = Step2Form(request.POST)
		if form.is_valid():
			application = Application.objects.get(pk=application_id)
			
			
			contact_residence_country = form.cleaned_data.get('contact_residence_country')
			contact_residence_permit_number = form.cleaned_data.get('contact_residence_permit_number')
			contact_valid_until = form.cleaned_data.get('contact_valid_until')
			contact_address = form.cleaned_data.get('contact_address')
			contact_postal_code = form.cleaned_data.get('contact_postal_code')
			contact_city_of_residence = form.cleaned_data.get('contact_city_of_residence')
			contact_country_of_residence = form.cleaned_data.get('contact_country_of_residence')
			contact_phone = form.cleaned_data.get('contact_phone')
			contact_fax = form.cleaned_data.get('contact_fax')
			contact_email = form.cleaned_data.get('contact_email')
			guardian_surname = form.cleaned_data.get('guardian_surname')
			guardian_firstname = form.cleaned_data.get('guardian_firstname')
			guardian_address = form.cleaned_data.get('guardian_address')
			guardian_nationality = form.cleaned_data.get('guardian_nationality')
			guardian_postal_code = form.cleaned_data.get('guardian_postal_code')
			guardian_city = form.cleaned_data.get('guardian_city')
			guardian_country = form.cleaned_data.get('guardian_country')
			guardian_phone = form.cleaned_data.get('guardian_phone')
			guardian_fax = form.cleaned_data.get('guardian_fax')
			guardian_email = form.cleaned_data.get('guardian_email')


			application.contact_residence_country = contact_residence_country
			application.contact_residence_permit_number = contact_residence_permit_number
			application.contact_valid_until = contact_valid_until
			application.contact_address = contact_address
			application.contact_postal_code = contact_postal_code
			application.contact_city_of_residence = contact_city_of_residence
			application.contact_country_of_residence = contact_country_of_residence
			application.contact_phone = contact_phone
			application.contact_fax = contact_fax
			application.contact_email = contact_email
			application.guardian_surname = guardian_surname
			application.guardian_firstname = guardian_firstname
			application.guardian_address = guardian_address
			application.guardian_nationality = guardian_nationality
			application.guardian_postal_code = guardian_postal_code
			application.guardian_city = guardian_city
			application.guardian_country = guardian_country
			application.guardian_phone = guardian_phone
			application.guardian_fax = guardian_fax
			application.guardian_email = guardian_email

			application.save()
			return redirect('step3',application_id=application_id)
		else:
			return render(request, 'application/step2.html',{'application_id':application_id,'form':form})

	else:
		form = Step2Form()
		application = Application.objects.get(pk=application_id)
		if application.passport_type is not None:
			form = Step2Form(initial={
			'contact_residence_country' : application.contact_residence_country,
			'contact_residence_permit_number' : application.contact_residence_permit_number,
			'contact_valid_until' : application.contact_valid_until,
			'contact_address' : application.contact_address,
			'contact_postal_code' : application.contact_postal_code,
			'contact_city_of_residence' : application.contact_city_of_residence,
			'contact_country_of_residence' : application.contact_country_of_residence,
			'contact_phone' : application.contact_phone,
			'contact_fax' : application.contact_fax,
			'contact_email' : application.contact_email,
			'guardian_surname' : application.guardian_surname,
			'guardian_firstname' : application.guardian_firstname,
			'guardian_address' : application.guardian_address,
			'guardian_nationality' : application.guardian_nationality,
			'guardian_postal_code' : application.guardian_postal_code,
			'guardian_city' : application.guardian_city,
			'guardian_country' : application.guardian_country,
			'guardian_phone' : application.guardian_phone,
			'guardian_fax' : application.guardian_fax,
			'guardian_email' : application.guardian_email,
			})

		return render(request, 'application/step2.html',{'application_id':application_id,'form':form,'application':application})

@login_required
def step3(request,application_id):
	if request.method=='POST':
		form = Step3Form(request.POST)
		if form.is_valid():
			application = Application.objects.get(pk=application_id)
			
			employment_current_occupation = form.cleaned_data.get('employment_current_occupation')
			employment_employer_name = form.cleaned_data.get('employment_employer_name')
			employment_employer_contact_number = form.cleaned_data.get('employment_employer_contact_number')
			employment_employer_address = form.cleaned_data.get('employment_employer_address')
			employment_employer_postal_code = form.cleaned_data.get('employment_employer_postal_code')
			employment_employer_city = form.cleaned_data.get('employment_employer_city')
			employment_employer_country = form.cleaned_data.get('employment_employer_country')
			employment_employer_fax = form.cleaned_data.get('employment_employer_fax')
			employment_employer_email = form.cleaned_data.get('employment_employer_email')
			
			application.employment_current_occupation = employment_current_occupation
			application.employment_employer_name = employment_employer_name
			application.employment_employer_contact_number = employment_employer_contact_number
			application.employment_employer_address = employment_employer_address
			application.employment_employer_postal_code = employment_employer_postal_code
			application.employment_employer_city = employment_employer_city
			application.employment_employer_country = employment_employer_country
			application.employment_employer_fax = employment_employer_fax
			application.employment_employer_email = employment_employer_email
			

			application.save()
			return redirect('step4',application_id=application_id)
		else:
			return render(request, 'application/step3.html',{'application_id':application_id,'form':form})

	else:
		form = Step3Form()
		application = Application.objects.get(pk=application_id)
		if application.employment_current_occupation is not None:
			form = Step3Form(initial={
			'employment_current_occupation' : application.employment_current_occupation,
			'employment_employer_name' : application.employment_employer_name,
			'employment_employer_contact_number' : application.employment_employer_contact_number,
			'employment_employer_address' : application.employment_employer_address,
			'employment_employer_postal_code' : application.employment_employer_postal_code,
			'employment_employer_city' : application.employment_employer_city,
			'employment_employer_country' : application.employment_employer_country,
			'employment_employer_fax' : application.employment_employer_fax,
			'employment_employer_email' : application.employment_employer_email,
			
			})

		return render(request, 'application/step3.html',{'application_id':application_id,'form':form,'application':application})

@login_required
def step4(request,application_id):
	if request.method=='POST':
		form = Step4Form(request.POST)
		if form.is_valid():
			application = Application.objects.get(pk=application_id)
			
			passport_country_of_issue = form.cleaned_data.get('passport_country_of_issue')
			passport_type = form.cleaned_data.get('passport_type')
			passport_number = form.cleaned_data.get('passport_number')
			passport_issue_date = form.cleaned_data.get('passport_issue_date')
			passport_expiry_date = form.cleaned_data.get('passport_expiry_date')
			passport_national_identity_number = form.cleaned_data.get('passport_national_identity_number')
			travel_main_purpose = form.cleaned_data.get('travel_main_purpose')
			travel_member_state_of_destination = form.cleaned_data.get('travel_member_state_of_destination')
			travel_member_state_of_first_entry = form.cleaned_data.get('travel_member_state_of_first_entry')
			travel_duration_intended_stay = form.cleaned_data.get('travel_duration_intended_stay')
			travel_visa_issued_past_years = form.cleaned_data.get('travel_visa_issued_past_years')
			travel_fingerprint_for_previous_visa = form.cleaned_data.get('travel_fingerprint_for_previous_visa')
			travel_visa_issued_past_years_sticker = form.cleaned_data.get('travel_visa_issued_past_years_sticker')
			travel_fingerprint_for_previous_visa_sticker = form.cleaned_data.get('travel_fingerprint_for_previous_visa_sticker')
			travel_entrypermit_finalcountry_destination = form.cleaned_data.get('travel_entrypermit_finalcountry_destination')
			travel_valid_from = form.cleaned_data.get('travel_valid_from')
			travel_valid_to = form.cleaned_data.get('travel_valid_to')
			travel_port_of_arrival = form.cleaned_data.get('travel_port_of_arrival')
			travel_total_entries_requested = form.cleaned_data.get('travel_total_entries_requested')
			travel_date_of_arrival = form.cleaned_data.get('travel_date_of_arrival')
			travel_date_of_departure = form.cleaned_data.get('travel_date_of_departure')
			travel_date_of_arrival_schengen = form.cleaned_data.get('travel_date_of_arrival_schengen')
			travel_date_of_departure_schengen = form.cleaned_data.get('travel_date_of_departure_schengen')
			
			application.passport_country_of_issue = passport_country_of_issue
			application.passport_type = passport_type
			application.passport_number = passport_number
			application.passport_issue_date = passport_issue_date
			application.passport_expiry_date = passport_expiry_date
			application.passport_national_identity_number = passport_national_identity_number
			application.travel_main_purpose = travel_main_purpose
			application.travel_member_state_of_destination = travel_member_state_of_destination
			application.travel_member_state_of_first_entry = travel_member_state_of_first_entry
			application.travel_duration_intended_stay = travel_duration_intended_stay
			application.travel_visa_issued_past_years = travel_visa_issued_past_years
			application.travel_fingerprint_for_previous_visa = travel_fingerprint_for_previous_visa
			application.travel_visa_issued_past_years_sticker = travel_visa_issued_past_years_sticker
			application.travel_fingerprint_for_previous_visa_sticker = travel_fingerprint_for_previous_visa_sticker
			application.travel_entrypermit_finalcountry_destination = travel_entrypermit_finalcountry_destination
			application.travel_valid_from = travel_valid_from
			application.travel_valid_to = travel_valid_to
			application.travel_port_of_arrival = travel_port_of_arrival
			application.travel_total_entries_requested = travel_total_entries_requested
			application.travel_date_of_arrival = travel_date_of_arrival
			application.travel_date_of_departure = travel_date_of_departure
			application.travel_date_of_arrival_schengen = travel_date_of_arrival_schengen
			application.travel_date_of_departure_schengen = travel_date_of_departure_schengen
			

			application.save()
			return redirect('step5',application_id=application_id)
		else:
			return render(request, 'application/step4.html',{'application_id':application_id,'form':form})

	else:
		form = Step4Form()
		application = Application.objects.get(pk=application_id)
		if application.passport_type is not None:
			form = Step4Form(initial={
			'passport_country_of_issue' : application.passport_country_of_issue,
			'passport_type' : application.passport_type,
			'passport_number' : application.passport_number,
			'passport_issue_date' : application.passport_issue_date,
			'passport_expiry_date' : application.passport_expiry_date,
			'passport_national_identity_number' : application.passport_national_identity_number,
			'travel_main_purpose' : application.travel_main_purpose,
			'travel_member_state_of_destination' : application.travel_member_state_of_destination,
			'travel_member_state_of_first_entry' : application.travel_member_state_of_first_entry,
			'travel_duration_intended_stay' : application.travel_duration_intended_stay,
			'travel_visa_issued_past_years' : application.travel_visa_issued_past_years,
			'travel_fingerprint_for_previous_visa' : application.travel_fingerprint_for_previous_visa,
			'travel_visa_issued_past_years_sticker' : application.travel_visa_issued_past_years_sticker,
			'travel_fingerprint_for_previous_visa_sticker' : application.travel_fingerprint_for_previous_visa_sticker,
			'travel_entrypermit_finalcountry_destination' : application.travel_entrypermit_finalcountry_destination,
			'travel_valid_from' : application.travel_valid_from,
			'travel_valid_to' : application.travel_valid_to,
			'travel_port_of_arrival' : application.travel_port_of_arrival,
			'travel_total_entries_requested' : application.travel_total_entries_requested,
			'travel_date_of_arrival' : application.travel_date_of_arrival,
			'travel_date_of_departure' : application.travel_date_of_departure,
			'travel_date_of_arrival_schengen' : application.travel_date_of_arrival_schengen,
			'travel_date_of_departure_schengen' : application.travel_date_of_departure_schengen,
			
			})

		return render(request, 'application/step4.html',{'application_id':application_id,'form':form,'application':application})

@login_required
def step5(request,application_id):
	if request.method=='POST':
		form = Step5Form(request.POST)
		if form.is_valid():
			application = Application.objects.get(pk=application_id)
			
			hotel_type = form.cleaned_data.get('hotel_type')
			hotel_name = form.cleaned_data.get('hotel_name')
			hotel_phone = form.cleaned_data.get('hotel_phone')
			hotel_address = form.cleaned_data.get('hotel_address')
			hotel_postal_code = form.cleaned_data.get('hotel_postal_code')
			hotel_city = form.cleaned_data.get('hotel_city')
			hotel_province = form.cleaned_data.get('hotel_province')
			hotel_fax = form.cleaned_data.get('hotel_fax')
			hotel_email = form.cleaned_data.get('hotel_email')
			hotel_invite_name = form.cleaned_data.get('hotel_invite_name')
			hotel_invite_address = form.cleaned_data.get('hotel_invite_address')
			hotel_invite_postal_code = form.cleaned_data.get('hotel_invite_postal_code')
			hotel_invite_city = form.cleaned_data.get('hotel_invite_city')
			hotel_invite_province = form.cleaned_data.get('hotel_invite_province')
			hotel_invite_phone = form.cleaned_data.get('hotel_invite_phone')
			hotel_invite_fax = form.cleaned_data.get('hotel_invite_fax')
			hotel_invite_email = form.cleaned_data.get('hotel_invite_email')
			hotel_invite_company_surname = form.cleaned_data.get('hotel_invite_company_surname')
			hotel_invite_company_name = form.cleaned_data.get('hotel_invite_company_name')
			hotel_invite_company_email = form.cleaned_data.get('hotel_invite_company_email')
			hotel_invite_company_expenses = form.cleaned_data.get('hotel_invite_company_expenses')
			hotel_invite_company_support = form.cleaned_data.get('hotel_invite_company_support')
			family_surname = form.cleaned_data.get('family_surname')
			family_name = form.cleaned_data.get('family_name')
			family_date_of_birth = form.cleaned_data.get('family_date_of_birth')
			family_nationality = form.cleaned_data.get('family_nationality')
			family_id = form.cleaned_data.get('family_id')
			family_constraint = form.cleaned_data.get('family_constraint')

			application.hotel_type = hotel_type
			application.hotel_name = hotel_name
			application.hotel_phone = hotel_phone
			application.hotel_address = hotel_address
			application.hotel_postal_code = hotel_postal_code
			application.hotel_city = hotel_city
			application.hotel_province = hotel_province
			application.hotel_fax = hotel_fax
			application.hotel_email = hotel_email
			application.hotel_invite_name = hotel_invite_name
			application.hotel_invite_address = hotel_invite_address
			application.hotel_invite_postal_code = hotel_invite_postal_code
			application.hotel_invite_city = hotel_invite_city
			application.hotel_invite_province = hotel_invite_province
			application.hotel_invite_phone = hotel_invite_phone
			application.hotel_invite_fax = hotel_invite_fax
			application.hotel_invite_email = hotel_invite_email
			application.hotel_invite_company_surname = hotel_invite_company_surname
			application.hotel_invite_company_name = hotel_invite_company_name
			application.hotel_invite_company_email = hotel_invite_company_email
			application.hotel_invite_company_expenses = hotel_invite_company_expenses
			application.hotel_invite_company_support = hotel_invite_company_support
			application.family_surname = family_surname
			application.family_name = family_name
			application.family_date_of_birth = family_date_of_birth
			application.family_nationality = family_nationality
			application.family_id = family_id
			application.family_constraint = family_constraint
			

			application.save()
			return redirect('step6',application_id=application_id)
		else:
			return render(request, 'application/step5.html',{'application_id':application_id,'form':form})

	else:
		form = Step5Form()
		application = Application.objects.get(pk=application_id)
		if application.hotel_type is not None:
			form = Step5Form(initial={
			'hotel_type' : application.hotel_type,
			'hotel_name' : application.hotel_name,
			'hotel_phone' : application.hotel_phone,
			'hotel_address' : application.hotel_address,
			'hotel_postal_code' : application.hotel_postal_code,
			'hotel_city' : application.hotel_city,
			'hotel_province' : application.hotel_province,
			'hotel_fax' : application.hotel_fax,
			'hotel_email' : application.hotel_email,
			'hotel_invite_name' : application.hotel_invite_name,
			'hotel_invite_address' : application.hotel_invite_address,
			'hotel_invite_postal_code' : application.hotel_invite_postal_code,
			'hotel_invite_city' : application.hotel_invite_city,
			'hotel_invite_province' : application.hotel_invite_province,
			'hotel_invite_phone' : application.hotel_invite_phone,
			'hotel_invite_fax' : application.hotel_invite_fax,
			'hotel_invite_email' : application.hotel_invite_email,
			'hotel_invite_company_surname' : application.hotel_invite_company_surname,
			'hotel_invite_company_name' : application.hotel_invite_company_name,
			'hotel_invite_company_email' : application.hotel_invite_company_email,
			'hotel_invite_company_expenses' : application.hotel_invite_company_expenses,
			'hotel_invite_company_support' : application.hotel_invite_company_support,
			'family_surname' : application.family_surname,
			'family_name' : application.family_name,
			'family_date_of_birth' : application.family_date_of_birth,
			'family_nationality' : application.family_nationality,
			'family_id' : application.family_id,
			'family_constraint' : application.family_constraint,
			
			})

		return render(request, 'application/step5.html',{'application_id':application_id,'form':form,'application':application})

@login_required
def step6(request,application_id):
	application = Application.objects.get(pk=application_id)
	fs = FileSystemStorage()
	if request.method=='POST':
		doc1 = request.FILES.get('doc1',False)
		doc2 = request.FILES.get('doc2',False)
		doc3 = request.FILES.get('doc3',False)
		doc4 = request.FILES.get('doc4',False)
		doc5 = request.FILES.get('doc5',False)
		doc6 = request.FILES.get('doc6',False)
		doc7 = request.FILES.get('doc7',False)
		doc8 = request.FILES.get('doc8',False)
		doc9 = request.FILES.get('doc9',False)
		if doc1:
			s = str(doc1.name)
			s = ''.join(e for e in s if e.isalnum())
			filename = fs.save(s, doc1)
			uploaded_file_url = fs.url(filename)
			doc_image = str(uploaded_file_url)
			print doc_image
			application.document_passport_copy = doc1
		if doc2:
			application.document_latest_schengen_visa = doc2
		if doc3:
			application.document_latest_usa_visa = doc3
		if doc4:
			application.document_passport_photo = doc4
		if doc5:
			application.document_bank_statement_0 = doc5
		if doc6:
			application.document_bank_statement_1 = doc6
		if doc7:
			application.document_bank_statement_2 = doc7
		if doc8:
			application.document_hotel_reservation = doc8
		if doc9:
			application.document_flight_booking = doc9
		application.save()
		redirect('dashboard')


		  
	return render(request, 'application/step6.html',{'application_id':application_id})

def pricing(request):
	return render(request, 'application/pricing.html')



@login_required
def triprequirements(request,application_id):
	return render(request, 'application/triprequirements.html',{'application_id':application_id})

@login_required
def checkrequirement(request):
	if request.method=='POST':
		
		passport_type = request.POST.get('passport_type')
		travelling_to = request.POST.get('travelling_to')
		currently_live = request.POST.get('currently_live')
		trip_purpose = request.POST.get('trip_purpose')
		application  = Application.objects.create(
				username = request.user.username,
				visa_country_traveling_to = travelling_to
			)

		application_id = application.id
		print passport_type,travelling_to,currently_live,trip_purpose
		return redirect('triprequirements',application_id=application_id)
		

	else:
		
		return render(request, 'application/checkrequirement.html')


def signup(request):
	if request.method=='POST':
		form = SignupForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('login')
		else:
			return render(request, 'application/signup.html',{'form':form})
	else:
		form = SignupForm()
		return render(request, 'application/signup.html',{'form':form})