from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

COUNTRY_LIST = [('Please Select','Please Select'),
('Afghanistan', 'Afghanistan'),('Austria','Austria'),('Australia','Australia'), ('Albania', 'Albania'), ('Algeria', 'Algeria'),  ('Andorra', 'Andorra'), ('Angola', 'Angola'), ('Anguilla', 'Anguilla'), ('Antigua and Barbuda', 'Antigua and Barbuda'), ('Argentina', 'Argentina'), ('Armenia', 'Armenia'),  ('Azerbaijan', 'Azerbaijan'), ('Bahamas', 'Bahamas'), ('Bahrain', 'Bahrain'), ('Bangladesh', 'Bangladesh'), ('Barbados', 'Barbados'), ('Belarus', 'Belarus'), ('Belgium', 'Belgium'), ('Belize', 'Belize'), ('Benin', 'Benin'), ('Bhutan', 'Bhutan'), ('Brunei Darussalam', 'Brunei Darussalam'), ('Burkina Faso', 'Burkina Faso'), ('Burundi', 'Burundi'), ('Cambodia', 'Cambodia'), ('Cameroon', 'Cameroon'), ('Canada', 'Canada'), ('Cayman Islands', 'Cayman Islands'), ('Central African Republic', 'Central African Republic'), ('Chad', 'Chad'), ('Chile', 'Chile'), ('China', 'China'), ('Colombia', 'Colombia'), ('Comoros', 'Comoros'), ('Congo Democratic Republic of', 'Congo Democratic Republic of'),  ("Cote D'Ivoire", "Cote D'Ivoire"),  ('Cuba', 'Cuba'),  ('Denmark', 'Denmark'), ('Djibouti', 'Djibouti'), ('Dominica', 'Dominica'), ('Dominican Republic', 'Dominican Republic'),('Ecuador', 'Ecuador'), ('Egypt', 'Egypt'), ('El Salvador', 'El Salvador'), ('Equatorial Guinea', 'Equatorial Guinea'), ('Eritrea', 'Eritrea'), ('Estonia', 'Estonia'), ('Ethiopia', 'Ethiopia'), ('Falkland Islands (Malvinas)', 'Falkland Islands (Malvinas)'), ('Faroe Islands', 'Faroe Islands'), ('Fiji', 'Fiji'), ('Finland', 'Finland'), ('France', 'France'), ('French Guiana', 'French Guiana'), ('French Polynesia', 'French Polynesia'), ('Gabon', 'Gabon'), ('Gambia', 'Gambia'), ('Georgia', 'Georgia'), ('Germany', 'Germany'), ('Ghana', 'Ghana'), ('Gibraltar', 'Gibraltar'), ('Greece', 'Greece'), ('Greenland', 'Greenland'), ('Grenada', 'Grenada'), ('Guadeloupe', 'Guadeloupe'),  ('Guatemala', 'Guatemala'), ('Guinea', 'Guinea'), ('Guinea-bissau', 'Guinea-bissau'), ('Guyana', 'Guyana'), ('Haiti', 'Haiti'), ('Honduras', 'Honduras'), ('Hong Kong', 'Hong Kong'), ('Hungary', 'Hungary'), ('Iceland', 'Iceland'), ('India', 'India'), ('Indonesia', 'Indonesia'), ('Iraq', 'Iraq'), ('Ireland', 'Ireland'), ('Israel', 'Israel'), ('Italy', 'Italy'), ('Jamaica', 'Jamaica'), ('Japan', 'Japan'), ('Jordan', 'Jordan'), ('Kazakhstan', 'Kazakhstan'), ('Kenya', 'Kenya'), ('Kiribati', 'Kiribati'), ('Kuwait', 'Kuwait'), ('Kyrgyzstan', 'Kyrgyzstan'), ("Lao People's Democratic Republic", "Lao People's Democratic Republic"), ('Latvia', 'Latvia'), ('Lebanon', 'Lebanon'), ('Lesotho', 'Lesotho'), ('Liberia', 'Liberia'), ('Libya', 'Libya'), ('Liechtenstein', 'Liechtenstein'), ('Lithuania', 'Lithuania'), ('Luxembourg', 'Luxembourg'), ('Macedonia', 'Macedonia'), ('Madagascar', 'Madagascar'), ('Malawi', 'Malawi'), ('Malaysia', 'Malaysia'), ('Maldives', 'Maldives'), ('Mali', 'Mali'), ('Malta', 'Malta'), ('Marshall Islands', 'Marshall Islands'),('Mauritania', 'Mauritania'), ('Mauritius', 'Mauritius'), ('Mexico', 'Mexico'), ('Micronesia', 'Micronesia'), ('Moldova', 'Moldova'), ('Monaco', 'Monaco'), ('Mongolia', 'Mongolia'), ('Montserrat', 'Montserrat'), ('Morocco', 'Morocco'), ('Mozambique', 'Mozambique'), ('Myanmar', 'Myanmar'), ('Namibia', 'Namibia'), ('Nauru', 'Nauru'), ('Nepal', 'Nepal'), ('Netherlands', 'Netherlands'), ('Netherlands Antilles', 'Netherlands Antilles'), ('New Caledonia', 'New Caledonia'), ('New Zealand', 'New Zealand'), ('Nicaragua', 'Nicaragua'), ('Niger', 'Niger'), ('Nigeria', 'Nigeria'), ('Niue', 'Niue'), ('Norfolk Island', 'Norfolk Island'), ('Northern Mariana Islands', 'Northern Mariana Islands'), ('Norway', 'Norway'), ('Oman', 'Oman'), ('Pakistan', 'Pakistan'), ('Palau', 'Palau'), ('Panama', 'Panama'), ('Papua New Guinea', 'Papua New Guinea'), ('Paraguay', 'Paraguay'), ('Peru', 'Peru'), ('Philippines', 'Philippines'), ('Pitcairn', 'Pitcairn'), ('Poland', 'Poland'), ('Portugal', 'Portugal'), ('Puerto Rico', 'Puerto Rico'), ('Qatar', 'Qatar'), ('Reunion', 'Reunion'), ('Romania', 'Romania'), ('Russian Federation', 'Russian Federation'), ('Rwanda', 'Rwanda'), ('Saint Kitts and Nevis', 'Saint Kitts and Nevis'), ('Saint Lucia', 'Saint Lucia'), ('Saint Vincent and the Grenadines', 'Saint Vincent and the Grenadines'), ('Samoa', 'Samoa'), ('San Marino', 'San Marino'), ('Sao Tome and Principe', 'Sao Tome and Principe'), ('Saudi Arabia', 'Saudi Arabia'), ('Senegal', 'Senegal'), ('Seychelles', 'Seychelles'), ('Sierra Leone', 'Sierra Leone'), ('Singapore', 'Singapore'), ('Slovakia (Slovak Republic)', 'Slovakia (Slovak Republic)'), ('Slovenia', 'Slovenia'), ('Solomon Islands', 'Solomon Islands'), ('Somalia', 'Somalia'), ('South Africa', 'South Africa'), ('South Georgia and the South Sandwich Islands', 'South Georgia and the South Sandwich Islands'), ('Spain', 'Spain'), ('Sri Lanka', 'Sri Lanka'), ('Saint Helena', 'Saint Helena'), ('St. Pierre and Miquelon', 'St. Pierre and Miquelon'), ('Suriname', 'Suriname'), ('Svalbard and Jan Mayen Islands', 'Svalbard and Jan Mayen Islands'), ('Swaziland', 'Swaziland'), ('Sweden', 'Sweden'), ('Switzerland', 'Switzerland'), ('Taiwan', 'Taiwan'), ('Tajikistan', 'Tajikistan'), ('Tanzania', 'Tanzania'), ('Thailand', 'Thailand'), ('Togo', 'Togo'), ('Tokelau', 'Tokelau'), ('Tonga', 'Tonga'), ('Trinidad and Tobago', 'Trinidad and Tobago'), ('Tunisia', 'Tunisia'), ('Turkey', 'Turkey'), ('Turkmenistan', 'Turkmenistan'), ('Turks and Caicos Islands', 'Turks and Caicos Islands'), ('Tuvalu', 'Tuvalu'), ('Uganda', 'Uganda'), ('Ukraine', 'Ukraine'), ('United Arab Emirates', 'United Arab Emirates'), ('United Kingdom', 'United Kingdom'), ('United States', 'United States'), ('United States Minor Outlying Islands', 'United States Minor Outlying Islands'), ('Uruguay', 'Uruguay'), ('Uzbekistan', 'Uzbekistan'), ('Vanuatu', 'Vanuatu'), ('Vatican City State (Holy See)', 'Vatican City State (Holy See)'), ('Venezuela', 'Venezuela'), ('Vietnam', 'Vietnam'), ('Virgin Islands (British)', 'Virgin Islands (British)'), ('Virgin Islands (U.S.)', 'Virgin Islands (U.S.)'), ('Wallis and Futuna Islands', 'Wallis and Futuna Islands'), ('Western Sahara', 'Western Sahara'), ('Yemen', 'Yemen'), ('Serbia', 'Serbia'), ('Zambia', 'Zambia'), ('Zimbabwe', 'Zimbabwe'), ('Aaland Islands', 'Aaland Islands'), ('Palestine', 'Palestine'), ('Montenegro', 'Montenegro'), ('Guernsey', 'Guernsey'), ('Isle of Man', 'Isle of Man'), ('Jersey', 'Jersey'), ('Cura\xc3\xa7ao', 'Cura\xc3\xa7ao'), ('Ivory Coast', 'Ivory Coast'), ('Kosovo', 'Kosovo')
]

class SignupForm(UserCreationForm):
    firstname = forms.CharField(required=True)
    lastname = forms.CharField(required=True)
    class Meta:
        
        model = User
        fields = ('username', 'firstname',  'lastname', 'password1', 'password2',
         )

class CheckRequirementForm(forms.Form):
    passport_type = forms.CharField(required=True)
    travelling_to = forms.CharField(widget=forms.Select(choices=COUNTRY_LIST))
    currently_live = forms.CharField(widget=forms.Select(choices=COUNTRY_LIST))
    trip_purpose = forms.CharField(required=True)

class Step1Form(forms.Form):
    surname = forms.CharField(required=True)
    surname_at_birth = forms.CharField(required=True)
    name = forms.CharField(required=True)
    date_of_birth = forms.DateField(required=True)
    place_of_birth = forms.CharField(required=True)
    country_of_birth = forms.CharField(required=True,widget=forms.Select(choices=COUNTRY_LIST))
    passport_nationality = forms.CharField(required=True,widget=forms.Select(choices=COUNTRY_LIST))
    nationality_at_birth = forms.CharField(required=True,widget=forms.Select(choices=COUNTRY_LIST))
    gender = forms.CharField(required=True,widget=forms.Select(choices=[('Please Select','Please Select'),('Male','Male'),('Female','Female')]))
    martial_status = forms.CharField(required=True,widget=forms.Select(choices=[('Please Select','Please Select'),('Married','Married'),('Separated','Separated'),('Divorced','Divorced'),('Widowed','Widowed'),('Single','Single')]))

class Step2Form(forms.Form):
    contact_residence_country = forms.CharField(required=False,widget=forms.Select(choices=COUNTRY_LIST))
    contact_residence_permit_number = forms.CharField(required=False)
    contact_valid_until = forms.DateField(required=False)
    contact_address = forms.CharField(required=True)
    contact_postal_code = forms.CharField(required=True)
    contact_city_of_residence = forms.CharField(required=True)
    contact_country_of_residence = forms.CharField(required=True,widget=forms.Select(choices=COUNTRY_LIST))
    contact_phone = forms.CharField(required=True)
    contact_fax = forms.CharField(required=False)
    contact_email = forms.CharField(required=True)
    guardian_surname = forms.CharField(required=False)
    guardian_firstname = forms.CharField(required=False)
    guardian_address = forms.CharField(required=False)
    guardian_nationality = forms.CharField(required=False,widget=forms.Select(choices=COUNTRY_LIST))
    guardian_postal_code = forms.CharField(required=False)
    guardian_city = forms.CharField(required=False)
    guardian_country = forms.CharField(required=False,widget=forms.Select(choices=COUNTRY_LIST))
    guardian_phone = forms.CharField(required=False)
    guardian_fax = forms.CharField(required=False)
    guardian_email = forms.CharField(required=False)

class Step3Form(forms.Form):
    employment_current_occupation = forms.CharField(required=True,widget=forms.Select(choices=[('Please Select','Please Select'),('Consultant','Consultant'),('Developer','Developer')]))
    employment_employer_name = forms.CharField(required=True)
    employment_employer_contact_number = forms.CharField(required=True)
    employment_employer_address = forms.CharField(required=True)
    employment_employer_postal_code = forms.CharField(required=True)
    employment_employer_city = forms.CharField(required=True)
    employment_employer_country = forms.CharField(required=True,widget=forms.Select(choices=COUNTRY_LIST))
    employment_employer_fax = forms.CharField(required=False)
    employment_employer_email = forms.CharField(required=True)


class Step4Form(forms.Form):
    passport_country_of_issue = forms.CharField(required=True,widget=forms.Select(choices=COUNTRY_LIST))
    passport_type = forms.CharField(required=True)
    passport_number = forms.CharField(required=True)
    passport_issue_date = forms.DateField(required=True)
    passport_expiry_date = forms.DateField(required=True)
    passport_national_identity_number = forms.CharField(required=False)
    travel_main_purpose = forms.CharField(required=True,widget=forms.Select(choices=[('Please Select','Please Select'),('Tourism','Tourism'),('Culture','Culture'),('Health Reasons','Health Reasons'),('Airport Transit','Airport Transit'),('Business','Business'),('Sport','Sport'),('Study','Study'),('Visiting Family','Visiting Family'),('Official Visit','Official Visit'),('Other','Other')]))
    travel_member_state_of_destination = forms.CharField(required=True,widget=forms.Select(choices=COUNTRY_LIST))
    travel_member_state_of_first_entry = forms.CharField(required=True,widget=forms.Select(choices=COUNTRY_LIST))
    travel_duration_intended_stay = forms.CharField(required=True)
    travel_visa_issued_past_years = forms.CharField(required=True,widget=forms.Select(choices=[('Please Select','Please Select'),('Yes','Yes'),('No','No')]))
    travel_fingerprint_for_previous_visa = forms.CharField(required=True,widget=forms.Select(choices=[('Please Select','Please Select'),('Yes','Yes'),('No','No')]))
    travel_visa_issued_past_years_sticker = forms.CharField(required=False)
    travel_fingerprint_for_previous_visa_sticker = forms.CharField(required=False)
    travel_entrypermit_finalcountry_destination = forms.CharField(required=False,widget=forms.Select(choices=COUNTRY_LIST))
    travel_entries_requested = forms.CharField(required=True)
    travel_valid_from = forms.DateField(required=False)
    travel_valid_to = forms.DateField(required=False)
    travel_port_of_arrival = forms.CharField(required=True)
    travel_date_of_arrival = forms.DateField(required=True)
    travel_date_of_departure = forms.DateField(required=True)
    travel_date_of_arrival_schengen = forms.DateField(required=True)
    travel_date_of_departure_schengen = forms.DateField(required=True)


class Step5Form(forms.Form):
    hotel_type = forms.CharField(required=True,widget=forms.Select(choices=[('Please Select','Please Select'),('Hotel/Temporary','Hotel/Temporary'),('Person','Person'),('Invitation','Invitation')]))
    hotel_name = forms.CharField(required=False)
    hotel_phone = forms.CharField(required=False)
    hotel_address = forms.CharField(required=False)
    hotel_postal_code = forms.CharField(required=False)
    hotel_city = forms.CharField(required=False)
    hotel_province = forms.CharField(required=False)
    hotel_fax = forms.CharField(required=False)
    hotel_email = forms.CharField(required=False)
    hotel_invite_name = forms.CharField(required=False)
    hotel_invite_address = forms.CharField(required=False)
    hotel_invite_postal_code = forms.CharField(required=False)
    hotel_invite_city = forms.CharField(required=False)
    hotel_invite_province = forms.CharField(required=False)
    hotel_invite_phone = forms.CharField(required=False)
    hotel_invite_fax = forms.CharField(required=False)
    hotel_invite_email = forms.CharField(required=False)
    hotel_invite_company_surname = forms.CharField(required=False)
    hotel_invite_company_name = forms.CharField(required=False)
    hotel_invite_company_email = forms.CharField(required=False)
    hotel_invite_company_expenses = forms.CharField(required=True,widget=forms.Select(choices=[('Please Select','Please Select'),('Oneself','Oneself'),('Inviting Person','Inviting Person'),('Inviting Company','Inviting Company'),('Other','Other')]))
    hotel_invite_company_support = forms.CharField(required=True,widget=forms.Select(choices=[('Please Select','Please Select'),('Autonomous','Autonomous'),('Declaration Warranty','Declaration Warranty'),('Official Invitation','Official Invitation'),('Prepaid Trip','Prepaid Trip'),('Scholarship','Scholarship')]))
    family_surname = forms.CharField(required=False)
    family_name = forms.CharField(required=False)
    family_date_of_birth = forms.DateField(required=False)
    family_nationality = forms.CharField(required=False,widget=forms.Select(choices=COUNTRY_LIST))
    family_id = forms.CharField(required=False)
    family_constraint = forms.CharField(required=False,widget=forms.Select(choices=[('Please Select','Please Select'),('Spouse','Spouse'),('Child','Child'),('Dependent Ascendant','Dependent Ascendant')]))


'''
#Step6
document_passport_copy = models.CharField(max_length=800,required=True)
document_latest_schengen_visa = models.CharField(max_length=800,required=True)
document_latest_usa_visa = models.CharField(max_length=800,required=True)
document_passport_photo = models.CharField(max_length=800,required=True)
document_bank_statement_0 = models.CharField(max_length=800,required=True)
document_bank_statement_1 = models.CharField(max_length=800,required=True)
document_bank_statement_2 = models.CharField(max_length=800,required=True)
document_hotel_reservation = models.CharField(max_length=800,required=True)
document_flight_booking = models.CharField(max_length=800,required=True)
approved_by_admin = models.BooleanField(default=False)
consulate = models.CharField(max_length=800,required=True)
'''


