from django.contrib import admin
from .models import Application
# Register your models here.
'''
class ApplicationAdmin(admin.ModelAdmin):
    
    fieldsets = (
        ('Visa Application', {
           'fields': ('username','visa_country_traveling_to','application_status'
                     )
        }),
        ('Step 1 | General Information', {
            'fields': ('first_name', 'middle_name','last_name',
                       'gender','martial_status',
                       'is_applicant_minor', 'country_of_birth','arrival_date','departure_date','port_of_arrival'
                      ),
        }),
        ('Step 2 | Passport and Contact Details', {
            'fields': ('passport_type','passport_number','passport_issue_date','passport_expiry_date','passport_nationality',
            			'passport_nationality_at_birth','passport_national_identity_number','passport_contact_country',
            			'passport_contact_city','passport_contact_home_address','passport_contact_phone_number','passport_contact_email'
                      ),
        }),
        ('Step 3 | Employment/Education Details', {
            'fields': ('employment_current_occupation','employment_employer_name',
            			'employment_employer_contact_number','employment_employer_address'
                      ),
        }),
        ('Step 4 | Travel Details', {
            'fields': ('travel_main_purpose',
'travel_member_state_of_destination',
'travel_member_state_of_first_entry',
'travel_entries_requested',
'travel_duration_intended_state',
'travel_visa_issued_last3_years',
'travel_fingerprint_for_previous_visa',
'travel_entrypermit_finalcountry_destination',
'travel_date_of_arrival',
'travel_date_of_departure',
                      ),
        }),
                ('Step 5 | Hotel/Invitation and Family Details', {
            'fields': ('hotel_who_staying_with',
'hotel_name_of_hotel',
'hotel_phone_of_hotel',
'hotel_address_of_hotel',
'hotel_cost_of_living',
'family_memberin_euzone',
'family_relation',
'family_fullname_of_member',
'family_nationality_of_member',
'family_dob_of_member',
'family_document_id_number'
                      ),
        }),

                        ('Step 6 | Documents', {
            'fields': ('document_passport_copy',
'document_latest_schengen_visa',
'document_latest_usa_visa',
'document_passport_photo',
'document_bank_statement_0',
'document_bank_statement_1',
'document_bank_statement_2',
'document_hotel_reservation',
'document_flight_booking',
                      ),
        }),

        ('Approved By Admin', {
           'fields': ('approved_by_admin','consulate',
                     )
        }),



    )
    

'''



admin.site.register(Application)
