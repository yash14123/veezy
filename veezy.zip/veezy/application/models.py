from django.db import models

# Create your models here.
class Application(models.Model):

    username = models.CharField(max_length=400)
    visa_country_traveling_to = models.CharField(max_length=400,null=True,blank=True)
    application_status = models.CharField(max_length=400,default='DRAFT')
    #Step1
    surname = models.CharField(max_length=400,null=True,blank=True)
    surname_at_birth = models.CharField(max_length=400,null=True,blank=True)
    name = models.CharField(max_length=400,null=True,blank=True)
    date_of_birth = models.DateField(null=True,blank=True)
    place_of_birth = models.CharField(max_length=400,null=True,blank=True)
    country_of_birth = models.CharField(max_length=400,null=True,blank=True)
    passport_nationality = models.CharField(max_length=400,null=True,blank=True)
    nationality_at_birth = models.CharField(max_length=400,null=True,blank=True)
    gender = models.CharField(max_length=400,null=True,blank=True)
    martial_status = models.CharField(max_length=400,null=True,blank=True)


    
    #Step2.1
    contact_residence_country = models.CharField(max_length=400,null=True,blank=True)
    contact_residence_permit_number = models.CharField(max_length=400,null=True,blank=True)
    contact_valid_until = models.CharField(max_length=400,null=True,blank=True)
    contact_address = models.CharField(max_length=400,null=True,blank=True)
    contact_postal_code = models.CharField(max_length=400,null=True,blank=True)
    contact_city_of_residence = models.CharField(max_length=400,null=True,blank=True)
    contact_country_of_residence = models.CharField(max_length=400,null=True,blank=True)
    contact_phone = models.CharField(max_length=400,null=True,blank=True)
    contact_fax = models.CharField(max_length=400,null=True,blank=True)
    contact_email = models.CharField(max_length=400,null=True,blank=True)
    #Step2.2
    guardian_surname = models.CharField(max_length=400,null=True,blank=True)
    guardian_firstname = models.CharField(max_length=400,null=True,blank=True)
    guardian_address = models.CharField(max_length=400,null=True,blank=True)
    guardian_nationality = models.CharField(max_length=400,null=True,blank=True)
    guardian_postal_code = models.CharField(max_length=400,null=True,blank=True)
    guardian_city = models.CharField(max_length=400,null=True,blank=True)
    guardian_country = models.CharField(max_length=400,null=True,blank=True)
    guardian_phone = models.CharField(max_length=400,null=True,blank=True)
    guardian_fax = models.CharField(max_length=400,null=True,blank=True)
    guardian_email = models.CharField(max_length=400,null=True,blank=True)



    #Step3
    employment_current_occupation = models.CharField(max_length=400,null=True,blank=True)
    employment_employer_name = models.CharField(max_length=400,null=True,blank=True)
    employment_employer_contact_number = models.CharField(max_length=400,null=True,blank=True)
    employment_employer_address = models.CharField(max_length=400,null=True,blank=True)
    employment_employer_postal_code = models.CharField(max_length=400,null=True,blank=True)
    employment_employer_city = models.CharField(max_length=400,null=True,blank=True)
    employment_employer_country = models.CharField(max_length=400,null=True,blank=True)
    employment_employer_fax = models.CharField(max_length=400,null=True,blank=True)
    employment_employer_email = models.CharField(max_length=400,null=True,blank=True)



    #Step4
    passport_country_of_issue = models.CharField(max_length=400,null=True,blank=True)
    passport_type = models.CharField(max_length=400,null=True,blank=True)
    passport_number = models.CharField(max_length=400,null=True,blank=True)
    passport_issue_date = models.DateField(null=True,blank=True)
    passport_expiry_date = models.DateField(null=True,blank=True)
    passport_national_identity_number = models.CharField(max_length=400,null=True,blank=True)
    travel_main_purpose = models.CharField(max_length=400,null=True,blank=True)
    travel_member_state_of_destination = models.CharField(max_length=400,null=True,blank=True)
    travel_member_state_of_first_entry = models.CharField(max_length=400,null=True,blank=True)
    travel_duration_intended_stay = models.CharField(max_length=400,null=True,blank=True)
    travel_visa_issued_past_years = models.CharField(max_length=400,null=True,blank=True)
    travel_fingerprint_for_previous_visa = models.CharField(max_length=400,null=True,blank=True)
    travel_visa_issued_past_years_sticker = models.CharField(max_length=400,null=True,blank=True)
    travel_fingerprint_for_previous_visa_sticker = models.CharField(max_length=400,null=True,blank=True)
    travel_entrypermit_finalcountry_destination = models.CharField(max_length=400,null=True,blank=True)
    travel_valid_from = models.DateField(null=True,blank=True)
    travel_valid_to = models.DateField(null=True,blank=True)
    travel_port_of_arrival = models.CharField(max_length=400,null=True,blank=True)
    travel_total_entries_requested = models.CharField(max_length=400,null=True,blank=True)
    travel_date_of_arrival = models.DateField(null=True,blank=True)
    travel_date_of_departure = models.DateField(null=True,blank=True)
    travel_date_of_arrival_schengen = models.DateField(null=True,blank=True)
    travel_date_of_departure_schengen = models.DateField(null=True,blank=True)


    
    #Step5
    hotel_type = models.CharField(max_length=400,null=True,blank=True)
    hotel_name = models.CharField(max_length=400,null=True,blank=True)
    hotel_phone = models.CharField(max_length=400,null=True,blank=True)
    hotel_address = models.CharField(max_length=400,null=True,blank=True)
    hotel_postal_code = models.CharField(max_length=400,null=True,blank=True)
    hotel_city = models.CharField(max_length=400,null=True,blank=True)
    hotel_province = models.CharField(max_length=400,null=True,blank=True)
    hotel_fax = models.CharField(max_length=400,null=True,blank=True)
    hotel_email = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_name = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_address = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_postal_code = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_city = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_province = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_phone = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_fax = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_email = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_company_surname = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_company_name = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_company_email = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_company_expenses = models.CharField(max_length=400,null=True,blank=True)
    hotel_invite_company_support = models.CharField(max_length=400,null=True,blank=True)
    family_surname = models.CharField(max_length=400,null=True,blank=True)
    family_name = models.CharField(max_length=400,null=True,blank=True)
    family_date_of_birth = models.DateField(null=True,blank=True)
    family_nationality = models.CharField(max_length=400,null=True,blank=True)
    family_id = models.CharField(max_length=400,null=True,blank=True)
    family_constraint = models.CharField(max_length=400,null=True,blank=True)



    #Step6
    document_passport_copy = models.ImageField(null=True,blank=True)
    document_latest_schengen_visa = models.ImageField(null=True,blank=True)
    document_latest_usa_visa = models.ImageField(null=True,blank=True)
    document_passport_photo = models.ImageField(null=True,blank=True)
    document_bank_statement_0 = models.ImageField(null=True,blank=True)
    document_bank_statement_1 = models.ImageField(null=True,blank=True)
    document_bank_statement_2 = models.ImageField(null=True,blank=True)
    document_hotel_reservation = models.ImageField(null=True,blank=True)
    document_flight_booking = models.ImageField(null=True,blank=True)




    
    approved_by_admin = models.BooleanField(default=False)
    consulate = models.CharField(max_length=800,null=True,blank=True)




    def __str__(self):
        return self.username
