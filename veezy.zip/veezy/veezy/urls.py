from django.conf.urls import include, url
from django.contrib import admin
from application import views as app_views
from django.contrib.auth import views as auth_views

urlpatterns = [
    # Examples:
    # url(r'^$', 'veezy.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r'^$', app_views.index, name='index'),
    url(r'^signup/$', app_views.signup, name='signup'),
    url(r'^dashboard/$', app_views.dashboard, name='dashboard'),
    url(r'^login/', auth_views.login, {'template_name': 'application/login.html'}, name='login'),
    url(r'^application/(?P<application_id>[0-9]+)/step1/$', app_views.step1, name='step1'),
    url(r'^application/(?P<application_id>[0-9]+)/step2/$', app_views.step2, name='step2'),
    url(r'^application/(?P<application_id>[0-9]+)/step3/$', app_views.step3, name='step3'),
    url(r'^application/(?P<application_id>[0-9]+)/step4/$', app_views.step4, name='step4'),
    url(r'^application/(?P<application_id>[0-9]+)/step5/$', app_views.step5, name='step5'),
    url(r'^application/(?P<application_id>[0-9]+)/step6/$', app_views.step6, name='step6'),
    url(r'^application/(?P<application_id>[0-9]+)/pricing/$', app_views.pricing, name='pricing'),
    url(r'^application/(?P<application_id>[0-9]+)/triprequirements/$', app_views.triprequirements, name='triprequirements'),
    url(r'^application/checkrequirement/$', app_views.checkrequirement, name='checkrequirement'),
    url(r'^logout/$', auth_views.logout, {'next_page': 'login'}, name='logout'),

]

handler404 = 'application.views.view_404' 